<?php
$hostname = "localhost";
$username = "ratcliffm";
$password = "kJPowCviODxW19ZQzP1cBXovquirCqoj";
$schema = "f21_myGroceries";
?>