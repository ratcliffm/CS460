<!DOCTYPE html>
<html>
<head>
<!-- 
*	Filename: member_trig.php
* 	Author: Maliah Ratcliff
* 	Last Updated: Fall 2021
*	Class: CS460
*
*	Purpose: This file shows the results of adding a user to a household which will fire
*			the trigger on the mygroceries user table. 
*
-->
</head>
<body>
<h2> Trigger Execution Results </h2>
<h4> Author: Maliah Ratcliff </h4>

<p> This pages shows the record associated with the new user you added, which was validated 
by the trigger. All users added to the
hosehold with the corresponding chosen ID should have an increased household number. </p>

<?php // signifies the start of PHP code
require_once '/home/SOU/ratcliffm/dbconfig_groceries.php';

// Turn error report on
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
ini_set('display_errors', '1');

$dbconnect = new mysqli($hostname,$username,$password,$schema);

if ($dbconnect->connect_error) {
  die("Database connection failed: " . $dbconnect->connect_error);
}
//echo "Connected successfully... </br>";

if(isset($_POST['submit'])) {
	$userid=$_POST['user_id'];
	$username=$_POST['user_name'];
	$email=$_POST['email'];
	$household=$_POST['household_id'];
    
    $stmt = $dbconnect->prepare("INSERT INTO mygroceries_user (user_id, user_name, email, household_id)
        VALUES(?, ?, ?, ?)") or die($dbconnect->error);
        $stmt->bind_param("issi",$userid, $username, $email, $household); 
	$stmt->execute() or die($stmt->error);
	$stmt->close();
	
	/* prepare a new statement to get result */
	$resultstmt = $dbconnect->prepare("select num_people_in_household, household_id from household where household_id = ?") or die($dbconnect->error);
	$resultstmt->bind_param("i",$household);
	// if the statement returns an error (e.g., because salary value is too high) print error before exiting
	$resultstmt->execute() or die($stmt->error);
	// if statement executed successfully get results and process them
	$retval = $resultstmt->get_result();  
    if ($retval->num_rows > 0){
		/* while there is more data to fetch */
		while($row = $retval->fetch_assoc()) {  
			echo "
                Number of People in household:  {$row['num_people_in_household']}<br/>
                Household ID:  {$row['household_id']}<br/>";
		}
	}
	$retval->free_result();
}
// close connection
$dbconnect->close();
?> <!-- signifiies the end of PHP code -->
</body>
</html>