<!DOCTYPE html>
<html>
<head>
	<!-- House Report -->
	<!-- Written by Maliah Ratcliff -->
	<!-- Last Updated Fall 2021 -->
</head>

<body>

<h2> Household Spending Report </h2>
	<h4> Author: Maliah Ratcliff </h4>
	<h4 style="display:inline;">Description: </h4>
	<p style="display:inline;"> This pages shows the purchase history for each user in the household. </p>
<br/>
<br/>
<!-- start of table to hold data return by query -->
<table border="1" align="left">
<tr>
  <th>User Name </th>
  <th>Household ID </th>
  <th>Purchase Total for User </th>
</tr>

<?php // signifies the start of PHP code, notice how the comment markers differ

// include credientals which should be stored outside your root directory (i.e. outside public_html)
// do NOT use '../' in file path
require_once '/home/SOU/ratcliffm/dbconfig_groceries.php';

// Turn error reporting on
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
ini_set('display_errors', '1');

// create connection to DB - OOP
$dbconnect = new mysqli($hostname,$username,$password,$schema);

if (mysqli_connect_errno()) {
  printf("Database connection failed: " . mysqli_connect_errno());
  exit();
}
//echo "Connected Successfully"; 

if(isset($_POST['submit'])) {
	/* use a prepared statement to prevent SQL injection, see page 280 in course text */
	/* get value from post and store it in local variable */
	$household_id = $_POST['household_id']; /* empname is name of the variable that was posted by view_employee.html */

	$stmt = $dbconnect->query("SELECT * FROM house_spending_report WHERE household_id = $household_id")
	  	or die($dbconnect->error);
	
	/* get result set */
	// $retval = $stmt->get_result();  
    if ($stmt->num_rows > 0){
		/* while there is more data to fetch data in row array, then output the fields of
		interest by field name into the HTML table */
		while($row = $stmt->fetch_assoc()) {  
			echo "
				<tr>
				<td>{$row['user_name']}</td>  
				<td>{$row['household_id']}</td>
				<td>{$row['purchase_total']}</td>
				</tr>\n";  
		}
		echo "</table>"; // when there are not more rows to process close the HTML table
	} else {
		echo "</table><br><br>No results found "; // no data found, close table, print message
	}
	// free result set (acts on statement object not mysqli object)
	$stmt->free_result();
	//close connection using mysqli object
	$dbconnect->close(); 
}

?> <!-- signifiies the end of PHP code -->
</body>
</html>
