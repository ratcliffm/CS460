<!DOCTYPE html>
<html>
<head>
	<!-- Procedure For Stores -->
	<!-- Written by Maliah Ratcliff -->
	<!-- Last Updated Fall 2021 -->
</head>

<body>
<table border="1" align="center">
<tr>
  <th>Store</th>
  <th>Purchase Total</th>
</tr>


<?php
// notice this uses a different config file than the other examples
//require_once '/home/SOU/ratcliffm/dbconfig_groceries.php';
require_once '/home/SOU/ratcliffm/dbconfig_groceries.php';

// Turn error reporting on
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
ini_set('display_errors', '1');

$dbconnect = new mysqli ($hostname,$username,$password,$schema);

if (mysqli_connect_errno()) {
    printf("Connection failed: " . mysqli_connect_errno());
    exit();
}
echo "Stores and Amount Spent for this user: <br>  <br>";

// if someone posts data 
if(isset($_POST['submit'])) {
	// get employee name value from post
    $userid=$_POST['p_user_id'];
    $date1=$_POST['p_date_1'];
    $date2=$_POST['p_date_2'];
    $amount=$_POST['p_amount'];
	// build query

    // call store_report(8429590, 20000621, 20270721, 96);
  	$query = "call store_report($userid, '$date1', '$date2', $amount)"; // string needs quotes
  	// if query is not successful
    //if (!mysqli_query($dbconnect, $query)) {
    //    die('An error occurred.');
    //} else {
    	$retval = mysqli_query($dbconnect, $query); 
		// if one or more rows were returned
		if(mysqli_num_rows($retval) > 0){  
			// whilte there is data to be fetch
			while($row = mysqli_fetch_assoc($retval)) {  
				// access data an build HTML table row
    			echo 
    	  			"
    	  			<tr>
                    <td>{$row['Store']}</td>
                    <td>{$row['Total spent here']}</td>
   		  			</tr>\n";  
			} // end while
		} else {  
			echo "No results found";  
		}
	 //}
}

// free result set
mysqli_free_result($retval);
//close connection
mysqli_close($dbconnect); 
?> <!-- signifiies the end of PHP code -->
</body>
</html>